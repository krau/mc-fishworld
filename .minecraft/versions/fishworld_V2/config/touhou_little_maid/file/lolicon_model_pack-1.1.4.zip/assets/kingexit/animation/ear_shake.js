Java.asJSONCompatible({
    animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
        earLeft = modelMap.get("earLeft");
        earRight = modelMap.get("earRight");

        var time = ageInTicks % 40;
        if (time < Math.PI * 4) {
            var rotationZ = -Math.abs(Math.sin(time * 0.25)) * 0.3;
            if (earLeft != undefined) {
                earLeft.setRotateAngleZ(rotationZ - 1.04);
            }
            if (earRight != undefined) {
                earRight.setRotateAngleZ(-2.08 - rotationZ);
            }
        } else {
            if (earLeft != undefined) {
                earLeft.setRotateAngleZ(-1.04);
            }
            if (earRight != undefined) {
                earRight.setRotateAngleZ(-2.08);
            }
        }
    }
})